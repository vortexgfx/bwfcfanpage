let images = [
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjiEkLYegF40ubFe43rZfOHPZxBH5QS_sLi3NiH0PAm0Pbc0eXnnxX_FG9&s=10",
  "https://www.datocms-assets.com/187683/1765965469-psi_sh_bolton_wanderers_forest_green_rovers_12sept202000007.jpg?auto=format",
  "https://cdn.bwfc.co.uk/sites/default/files/styles/cc_960x540/public/2026-09/shutterstock_editorial_17147553ks.jpg?h=9083e78c&itok=GOkG8NKw",
  "https://media.licdn.com/dms/image/v2/D4E22AQGDiuezQiHO_w/feedshare-shrink_800/B4EaA.mal.HEAo-/0/1787756653618?e=2147483647&v=beta&t=MGDvUlaB5qJDlSxqpzQiFIqUDCFRGLWGlt0n74Cbw6o",
  "https://ichef.bbci.co.uk/ace/standard/976/cpsprodpb/99F2/production/_108501493_bolton.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/f/f1/Bolton_macron_wanderers_stadium.jpg?utm_source=en.wikipedia.org&utm_campaign=index&utm_content=original"
];

let colors = ["#00132D", "#00193B", "#001E45", "#002657", "#002D67", "#00377E"];

let mainImg = document.getElementById("main-img");

let currentImg = 0;

function changeImg() {
  if (currentImg < images.length - 1) {
    currentImg++;
    console.log(currentImg);
  } else {
    currentImg = 0;
    console.log(currentImg);
  }
  mainImg.src = images[currentImg];
}
let currentColor = 0;
function changeBgColor() {
  if (event.key == " ") {
    if (currentColor < colors.length - 1) {
      currentColor++;
    } else {
      currentColor = 0;
    }
    document.body.style.background = colors[currentColor];
  }
}
mainImg.addEventListener("click", changeImg);
document.addEventListener("keypress", changeBgColor);
